package com.crypto.tool;

import android.util.Base64;
import java.nio.charset.StandardCharsets;

public class CryptoUtil {
    // 加密：明文→反转→补4空字符→Base64
    public static String encrypt(String plainText) {
        String reversed = new StringBuilder(plainText).reverse().toString();
        byte[] originBytes = reversed.getBytes(StandardCharsets.UTF_8);
        byte[] paddedBytes = new byte[originBytes.length + 4];
        System.arraycopy(originBytes, 0, paddedBytes, 0, originBytes.length);
        paddedBytes[paddedBytes.length - 4] = 0x00;
        paddedBytes[paddedBytes.length - 3] = 0x00;
        paddedBytes[paddedBytes.length - 2] = 0x00;
        paddedBytes[paddedBytes.length - 1] = 0x00;
        return Base64.encodeToString(paddedBytes, Base64.NO_WRAP);
    }

    // 解密：Base64→去空字符→反转
    public static String decrypt(String cipherText) {
        try {
            byte[] decodedBytes = Base64.decode(cipherText, Base64.NO_WRAP);
            if (decodedBytes.length < 4) {
                return "解密失败：密文格式错误（长度不足）";
            }
            byte[] validBytes = new byte[decodedBytes.length - 4];
            System.arraycopy(decodedBytes, 0, validBytes, 0, validBytes.length);
            return new StringBuilder(new String(validBytes, StandardCharsets.UTF_8)).reverse().toString();
        } catch (Exception e) {
            return "解密失败：" + e.getMessage();
        }
    }
}
