package com.crypto.tool;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private EditText inputText;
    private TextView resultText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 绑定控件
        inputText = findViewById(R.id.inputText);
        resultText = findViewById(R.id.resultText);
        Button encryptBtn = findViewById(R.id.encryptBtn);
        Button decryptBtn = findViewById(R.id.decryptBtn);

        // 加密按钮点击事件
        encryptBtn.setOnClickListener(v -> {
            String plain = inputText.getText().toString().trim();
            if (plain.isEmpty()) {
                resultText.setText(R.string.empty_input);
                return;
            }
            resultText.setText("加密结果：\n" + CryptoUtil.encrypt(plain));
        });

        // 解密按钮点击事件
        decryptBtn.setOnClickListener(v -> {
            String cipher = inputText.getText().toString().trim();
            if (cipher.isEmpty()) {
                resultText.setText(R.string.empty_input);
                return;
            }
            resultText.setText("解密结果：\n" + CryptoUtil.decrypt(cipher));
        });
    }
}
